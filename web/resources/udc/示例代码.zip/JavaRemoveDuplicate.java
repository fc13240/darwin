package com.darwin.comp;

import java.util.HashSet;
import java.util.Set;

import com.darwin.itf.CustomAction;
import com.darwin.util.slog.CompLoggerInterface;

/**
 * Java去重组件:单机Jar，需要继承CustomAction。</br>
 * 该示例程序实现了从HDFS获取数据，通过java程序去重，将结果保存到HDFS上。
 * 
 * @author mupeng
 *
 */
public class JavaRemoveDuplicate extends CustomAction {

	private static final long serialVersionUID = 2461183955101761992L;

	@Override
	public int runAction(CompLoggerInterface logger) throws Exception {
		// 获取页面输入的参数， 通过基类中的getCompCustomParam方法。
		String inputPath = getCompCustomParam("inputPath"); // 输入路径。
		Set<String> contentSet = new HashSet<String>(); // 通过java中的Set去重。
		// 使用基类中的readLine方法，按行读取HDFS数据。
		logger.info("input path:" + inputPath);
		while (readLine(inputPath, "UTF-8") != null) {
			String line = readLine(inputPath, "UTF-8").trim();
			logger.info(line);
			contentSet.add(line);
		}
		// 使用基类中的writeLine方法，按行写入HDFS。
		for (String line : contentSet) {
			writeLine(line + "\n");
		}
		
		// 使用logger可以在页面中打印日志。
		logger.info("自定义组件实现完成！");
		return 0;
	}

	/**
	 * 如果运算结果需要落地到HDFS，这里需要给出落地的文件名</br>
	 * 因为页面只给出到最终结果说在的路径。</br>
	 */
	@Override
	public String getOutputFileName() {
		// 可以指定一个固定名称，也可以按照周期时间规则生成文件名。
		return "rm_dup_result";
	}

	@Override
	public boolean terminateAction() throws Exception {
		// 协助终止for循环、终止线程（池）
		return false;
	}

}
