package com.darwin.comp;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;

import com.darwin.abs.CustomSparkAction;
import com.darwin.util.slog.CompLoggerInterface;

/**
 * Spark去重组件：Spark Jar，需要继承CustomSparkAction。
 * 该示例程序使用Spark去重。
 * 
 * @author mupeng
 *
 */
public class SparkRemoveDuplicate extends CustomSparkAction {

	private static final long serialVersionUID = 9123555311896322717L;

	@Override
	public int runAction(CompLoggerInterface logger) throws Exception {
		// 获取页面输入的参数， 通过基类中的getCompCustomParam方法。
		String inputPath = this.getCompCustomParam("hdfs_path");       // HDFS路径
		// Spark组件去重逻辑。
		JavaRDD<String> resultRdd = getHadoopRdd(inputPath, logger)
				.mapToPair(new PairFunction<String, String, Integer>() {
			private static final long serialVersionUID = 1L;

			@Override
			public Tuple2<String, Integer> call(String t) throws Exception {
				return new Tuple2<String, Integer>(t, 1);
			}
			
		}).reduceByKey(new Function2<Integer, Integer, Integer>() {
			private static final long serialVersionUID = 7727986215116381837L;

			@Override
			public Integer call(Integer v1, Integer v2) throws Exception {
				return 1;
			}
		}).map(new Function<Tuple2<String,Integer>, String>() {

			private static final long serialVersionUID = -4891649426560670938L;

			@Override
			public String call(Tuple2<String, Integer> v1) throws Exception {
				return v1._1;
			}
		});
		// 调用基类的storeRDD方法，将结果保存到HDFS上。
		storeRDD(resultRdd);
		
		return 0;
	}

}
